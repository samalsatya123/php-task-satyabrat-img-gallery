<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cian computing task</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
    <!-- Popup Container -->
    <div id="popup" class="popup">
        <span id="popup-close" class="popup-close">&times;</span>
        <button id="popup-prev" class="popup-nav-btn">
            <svg class="hL8u3" width="24" height="24" viewBox="0 0 24 24" version="1.1" aria-hidden="false"
                style="flex-shrink: 0;">
                <desc lang="en-US">Chevron left</desc>
                <path d="M15.5 18.5 14 20l-8-8 8-8 1.5 1.5L9 12l6.5 6.5Z"></path>
            </svg>
        </button>
        <button id="popup-next" class="popup-nav-btn">
            <svg class="hL8u3" width="24" height="24" viewBox="0 0 24 24" version="1.1" aria-hidden="false"
                style="flex-shrink: 0;">
                <desc lang="en-US">Chevron right</desc>
                <path d="M8.5 5.5 10 4l8 8-8 8-1.5-1.5L15 12 8.5 5.5Z"></path>
            </svg>
        </button>
        <div class="popup-content">
            <div class="popup-info-main-sec">
                <img id="popup-img" src="" alt="Popup Image">
                <div class="popup-info">
                    <span id="popup-description" class="popup-text"></span>
                    <span id="popup-likes" class="popup-text"></span>
                    <span id="popup-photographer" class="popup-text"></span>
                </div>
            </div>
        </div>
    </div>

    <div class="main-sec-container">
        <div class="msc-inner-sec">
            <div class="msc-heading-sec">
                <h1 class="msc-heading">Dynamic Image Gallery</h1>
                <p>Explore the best and latest image gallery.</p>
            </div>
            <div class="msc-main-box-sec" id="imgGallery">
                
            </div>
        </div>
    </div>
    <div id="loader" class="">
        <div class="loader-container">
            <div class="lds-ring">
                <div></div>
                <div></div>
                <div></div>
                <div></div>
            </div>
        </div>
    </div>
<script src="assets/js/jquery-3.1.1.min.js"></script>
<script src="assets/js/script.js"></script>
</body>
</html>