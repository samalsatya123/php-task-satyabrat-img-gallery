// Adding global variables for the current index and photo data
let currentIndex = 0;
let photosData = [];

// Function to fetch images
function getAllImg() {
    $("#loader").addClass("active-loader");
    $.ajax({
        url: 'controller/getAllImg.php',
        method: 'GET',
        dataType: 'json',
        success: function(data) {
            photosData = data;
            let imgGalleryHTML = '';
            if (data.length > 0) {
                data.forEach((photo, index) => {
                    imgGalleryHTML += `
                        <div class="msc-box" data-index="${index}">
                            <div class="msc-img-sec">
                                <img src="${photo.urls.regular}" alt="${photo.alt_description}">
                            </div>
                            <div class="msc-box-tag">
                                <span class="tag-text-content">${photo.alt_description || 'No description'}</span>
                                <span class="tag-text-content">Likes: ${photo.likes|| '0'}</span>
                                <span class="tag-text-content">Photographer: ${photo.user.name|| 'Unknown'}</span>
                            </div>
                        </div>
                    `;
                });
            } else {
                imgGalleryHTML = '<p>No data found.</p>'; // Display message if no data
            }
            $("#imgGallery").html(imgGalleryHTML);
        },
        error: function(xhr, status, error) {
            console.error('Error:', error);
        },
        complete: function() {
            $("#loader").removeClass("active-loader");
        }
    });
}

// Function to open the popup
function openPopup(index) {
    if (photosData[index]) {
        const photo = photosData[index];
        $("#popup-img").attr("src", photo.urls.regular);
        $("#popup-description").text(photo.alt_description || 'No description');
        $("#popup-likes").text(`Likes: ${photo.likes}`);
        $("#popup-photographer").text(`Photographer: ${photo.user.name}`);
        $("#popup").css("display", "flex");
        currentIndex = index;
    } else {
        console.error('Photo data is not available for index:', index);
    }
}
// Closing popup when the close button is clicked
$("#popup-close").on('click', function() {
    $("#popup").hide();
});

// Navigating to the previous image
$("#popup-prev").on('click', function() {
    if (currentIndex > 0) {
        openPopup(currentIndex - 1);
    }
});

// Navigating to the next image
$("#popup-next").on('click', function() {
    if (currentIndex < photosData.length - 1) {
        openPopup(currentIndex + 1);
    }
});

// Adding click event listener to each image box
$("#imgGallery").on('click', '.msc-box', function() {
    const index = $(this).data('index');
    openPopup(index);
});

// closing popup when clicking outside of the content
$("#popup").on('click', function(event) {
    if (event.target.id === 'popup') {
        $("#popup").hide();
    }
});

// Fetch images when the page loads
$(document).ready(function() {
    getAllImg();
});
